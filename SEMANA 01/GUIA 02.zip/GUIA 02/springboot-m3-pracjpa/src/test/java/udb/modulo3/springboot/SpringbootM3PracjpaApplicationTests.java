package udb.modulo3.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootM3PracjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
