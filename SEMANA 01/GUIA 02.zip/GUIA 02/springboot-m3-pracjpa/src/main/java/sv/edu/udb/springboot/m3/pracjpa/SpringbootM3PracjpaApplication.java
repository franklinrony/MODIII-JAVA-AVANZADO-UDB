package sv.edu.udb.springboot.m3.pracjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootM3PracjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootM3PracjpaApplication.class, args);
	}

}
